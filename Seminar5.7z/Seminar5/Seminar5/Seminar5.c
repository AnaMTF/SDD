#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<malloc.h>

typedef struct Masina Masina;
typedef struct Nod Nod;
typedef struct LDI LDI;

struct Masina {
	char* producator;
	int serie;
};

struct Nod {
	Masina inf;
	Nod* next;
	Nod* prev;
};

struct LDI { //Lista Dublu Inlantuita
	Nod* prim;
	Nod* ultim;
};

void afisareMasina(Masina masina) {
	printf("\n Masina %s are seria %d.", masina.producator, masina.serie);
}

Masina initMasina(const char* producator, int serie) {
	Masina masinaNoua;
	masinaNoua.serie = serie;
	masinaNoua.producator = (char*)malloc(sizeof(char) * (strlen(producator) + 1));
	strcpy(masinaNoua.producator, producator);

	return masinaNoua;
}

void inserareLaInceput(Masina masina, LDI* lista) {
	Nod* nodNou = (Nod*)malloc(sizeof(Nod)*1);
	nodNou->inf = masina;
	nodNou->prev = NULL;
	nodNou->next = lista->prim;
	if (lista->prim)
	{
		lista->prim->prev = nodNou;
		lista->prim = nodNou;
	}
	else
	{
		lista->prim = nodNou;
		lista->ultim = nodNou;
	}
	
}

void inserareLaFinal(Masina masina, LDI* lista) {
	Nod* nodNou = (Nod*)malloc(sizeof(Nod) * 1);
	nodNou->inf = masina;
	nodNou->prev = lista->ultim;
	nodNou->next = NULL;
	if (lista->ultim)
	{
		lista->ultim->next = nodNou;
		lista->ultim = nodNou;
	}
	else
	{
		lista->prim = nodNou;
		lista->ultim = nodNou;
	}
}

void traversareLista(LDI lista) {

	while (lista.prim) {
		afisareMasina(lista.prim->inf);
		lista.prim = lista.prim->next;
	}

}

void traversareInversaLista(LDI lista) {

	while (lista.ultim) {
		afisareMasina(lista.ultim->inf);
		lista.ultim = lista.ultim->prev;
	}

}

void numarareLista(LDI lista, int* nrMasini) {

	while (lista.prim) {
		(*nrMasini)++;
		lista.prim = lista.prim->next;
	}

}

void dezalocare(LDI* lista) { // nu inteleg
	Nod* copie = lista->prim;
	while (copie)
	{
		free(copie->inf.producator);
		copie = copie->next;
		if (copie) {
			free(copie->prev);
		}
	}
	free(lista->ultim);
	lista->prim = NULL;
	lista->ultim = NULL;
}

LDI dezalocareLDI(LDI lista) {
	Nod* copie = lista.prim;
	while (copie)
	{
		free(copie->inf.producator);
		copie = copie->next;
		if (copie) {
			free(copie->prev);
		}
	}
	free(lista.ultim);
	lista.prim = NULL;
	lista.ultim = NULL;
	return lista;
}

void conversieLaVector(LDI lista, Masina** vectorMasini) {

		int nrMasini = 0;
		while (lista.prim) {
			(*vectorMasini)[nrMasini] = initMasina(lista.prim->inf.producator, lista.prim->inf.serie); //deep copy
			nrMasini++;
			lista.prim = lista.prim->next;
			//tema sa folosim realloc
		}
	
}

//void traversareListaCirculara(LDI lista) {
//	Nod* temp = lista.prim;
//	while (temp->next != lista.prim) {
//		afisareMasina(temp->inf);
//		temp = temp->next;
//	}
//	afisareMasina(temp->inf);
//}

void traversareListaCirculara(LDI lista) {
	Nod* temp = lista.prim;
	do {
		afisareMasina(temp->inf);
		temp = temp->next;
	
	} while (temp != lista.prim);
}

void main() {
	LDI lista;
	lista.prim = NULL;
	lista.ultim = NULL;
	printf("\n Afisare masini din lista:");
	inserareLaInceput(initMasina("Dacia", 123), &lista);
	inserareLaInceput(initMasina("BMW", 124), &lista);
	inserareLaInceput(initMasina("Audi", 125), &lista);

	inserareLaFinal(initMasina("Mercedes", 126), &lista);
	inserareLaFinal(initMasina("Ford", 127), &lista);
	printf("\n\n Traversare lista: \n");
	traversareLista(lista);
	//tema traversare de la coada la cap
	printf("\n\n Traversare inversa lista: \n");
	traversareInversaLista(lista);
	int nrMasini = 0;
	numarareLista(lista, &nrMasini);
	printf("\n\n Numarul de masini este %d.", nrMasini);

	printf("\n\n Afisare masini din vector: \n");

	Masina* vectorMasini = (Masina*)malloc(sizeof(Masina)*nrMasini);
	conversieLaVector(lista, &vectorMasini);
	for (int i = 0; i < nrMasini; i++)
	{
		afisareMasina(vectorMasini[i]);
		free(vectorMasini[i].producator);
	}
	free(vectorMasini);

	//LISTA DUBLA CIRCULARA
	lista.ultim->next = lista.prim;
	lista.prim->prev = lista.ultim;

	//traversare Lista Dubla Circulara
	printf("\n\n Afisare masini din lista dubla circulara: \n");
	traversareListaCirculara(lista);

	//dezalocare(&lista);
	//lista = dezalocare(lista);
	lista = dezalocareLDI(lista);

}